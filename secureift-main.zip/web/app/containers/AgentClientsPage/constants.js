/*
 *
 * AgentClientsPage constants
 *
 */

export const DEFAULT_ACTION = 'app/AgentClientsPage/DEFAULT_ACTION';
