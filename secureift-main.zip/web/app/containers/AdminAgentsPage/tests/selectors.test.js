// import { selectAdminAgentsPageDomain } from '../selectors';

describe('selectAdminAgentsPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
