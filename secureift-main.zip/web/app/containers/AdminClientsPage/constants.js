/*
 *
 * AdminClientsPage constants
 *
 */

export const DEFAULT_ACTION = 'app/AdminClientsPage/DEFAULT_ACTION';
