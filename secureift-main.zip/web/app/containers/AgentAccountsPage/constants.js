/*
 *
 * AgentAccountsPage constants
 *
 */

export const DEFAULT_ACTION = 'app/AgentAccountsPage/DEFAULT_ACTION';
