/*
 * HomePage
 *
 * This is the first thing users see of our App, at the '/' route
 *
 */

import React from 'react';
import { FormattedMessage } from 'react-intl';
import messages from './messages';
import FormsInput from './../../components/FormsInput/index';
import './../../assets/css/style.css';

export default function HomePage() {
  return (
    <> </>
  );
}
