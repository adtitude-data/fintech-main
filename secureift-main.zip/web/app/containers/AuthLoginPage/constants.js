/*
 *
 * AuthLoginPage constants
 *
 */

export const DEFAULT_ACTION = 'app/AuthLoginPage/DEFAULT_ACTION';
