// import { selectAuthLoginPageDomain } from '../selectors';

describe('selectAuthLoginPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
