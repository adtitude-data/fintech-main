
/**
 *
 * Header
 *
 */

 import React, { memo } from 'react';
 import { FormattedMessage } from 'react-intl';
 import auth from 'containers/App/auth';
 import Logo from 'components/Logo';
 import { withRouter } from 'react-router-dom';
import LoggedInHeaderActions from './LoggedInHeaderActions';

  function TwofaValidatePin(props) {
    return (
      <></>
    );
  }

  TwofaValidatePin.propTypes = {};

  export default withRouter(TwofaValidatePin);


