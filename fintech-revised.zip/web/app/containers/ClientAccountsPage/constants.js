/*
 *
 * ClientAccountsPage constants
 *
 */

export const DEFAULT_ACTION = 'app/ClientAccountsPage/DEFAULT_ACTION';
