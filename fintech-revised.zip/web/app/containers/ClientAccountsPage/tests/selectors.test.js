// import { selectClientAccountsPageDomain } from '../selectors';

describe('selectClientAccountsPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
