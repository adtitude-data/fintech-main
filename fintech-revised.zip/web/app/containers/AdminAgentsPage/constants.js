/*
 *
 * AdminAgentsPage constants
 *
 */

export const DEFAULT_ACTION = 'app/AdminAgentsPage/DEFAULT_ACTION';
