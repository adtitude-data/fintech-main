/*
 *
 * TwoFaPage constants
 *
 */

export const DEFAULT_ACTION = 'app/TwoFaPage/DEFAULT_ACTION';
