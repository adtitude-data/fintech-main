// import { selectTwoFaPageDomain } from '../selectors';

describe('selectTwoFaPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
